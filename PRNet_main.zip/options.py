import argparse
parser = argparse.ArgumentParser(description='Test Change Detection Models')

####------------------------------------   ttsting parameters   --------------------------------------####

parser.add_argument('--test_batchsize', default=1, type=int, help='batchsize')
parser.add_argument('--num_workers', default=0, type=int, help='num_workers [24]')
parser.add_argument('--gpu_id', default="0", type=str, help='which gpu to run.')
parser.add_argument('--suffix', default=['.png','.jpg','.tif'], type=list, help='the suffix of the image files.')


####----------------------------------   path for loading data   -----------------------------------------####
parser.add_argument('--test1_dir', default='./RCCD/test/A', type=str, help='t1 image path for testing')
parser.add_argument('--test2_dir', default='./RCCD/test/B', type=str, help='t2 image path for testing')
parser.add_argument('--label_test', default='./RCCD/test/label', type=str, help='label path for testing')



####----------------------------   network loading and result saving   ------------------------------------####
parser.add_argument('--checkpoints_dir', type=str, default='./checkpoints/ablation studies/different loss/LEVIR', help='models are saved here')
parser.add_argument('--name', type=str, default='loss_cd+loss1+loss2+loss3', help='name of the experiment. It decides where to store samples and models')
parser.add_argument('--load_net', type=str, default='100_F1_0.87339_net.pth',
                        help='name of the experiment. It decides where to store samples and models') 
parser.add_argument('--results_dir', type=str, default='./result/', help='saves results here.')


####-------------------------------------   Model settings   -----------------------------------------####
parser.add_argument('--in_c', default=3, type=int, help='input channel')
parser.add_argument('--out_cls', default=1, type=int, help='output category')
###---------------------------------------   model setting   -----------------------------------------###

parser.add_argument('--node_num_4', default=2, type=int, help='setting of graph nodes number in semantic refinement module')
parser.add_argument('--node_num_5', default=4, type=int, help='setting of graph nodes number in semantic refinement module')