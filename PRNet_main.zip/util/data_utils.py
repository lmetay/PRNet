"""This module contains data read/save functions """
from torch.utils.data import Dataset
import torchvision.transforms as transforms
import os
from PIL import Image
import numpy as np
import torch
import matplotlib.pyplot as plt  

def is_image_file(filename):
    return any(filename.endswith(extension) for extension in ['.png','.tif', '.jpg', '.jpeg', '.PNG', '.JPG', '.JPEG'])

def make_one_hot(input, num_classes):
    """Convert class index tensor to one hot encoding tensor.

    Args:
         input: A tensor of shape [N, 1, *]
         num_classes: An int of number of class
    Returns:
        A tensor of shape [N, num_classes, *]
    """
    shape = np.array(input.shape)
    shape[1] = num_classes
    shape = tuple(shape)
    result = torch.zeros(shape)
    result = result.scatter_(1, input.cpu(), 1)
    return result

class MyDataset(Dataset):
    def __init__(self, args, A_path, B_path, lab_path_ori): 
        datalist = [name for name in os.listdir(A_path) for item in args.suffix if
                      os.path.splitext(name)[1] == item]
        datalist_lab_ori = [name for name in os.listdir(lab_path_ori) for item in args.suffix if
                      os.path.splitext(name)[1] == item]
            

        self.A_filenames = [os.path.join(A_path, x) for x in datalist if is_image_file(x)]
        self.B_filenames = [os.path.join(B_path, x) for x in datalist if is_image_file(x)]
        self.lab_ori_filenames = [os.path.join(lab_path_ori, x) for x in datalist_lab_ori if is_image_file(x)]  


        self.transform_RGB_A = get_transform(convert=True, normalize=True, is_pre=True, isRGB=True)
        self.transform_RGB_B = get_transform(convert=True, normalize=True, is_pre=False, isRGB=True) 
        self.transform_label = get_transform()


        self.out_cls = 2

    def __getitem__(self,index):
        fn = self.A_filenames[index]
        A_img = self.transform_RGB_A(Image.open(self.A_filenames[index]).convert('RGB')) 
        B_img = self.transform_RGB_B(Image.open(self.B_filenames[index]).convert('RGB'))

        label = self.transform_label(Image.open(self.lab_ori_filenames[index]))

        
        return A_img, B_img, label, index

    def __len__(self):
        return len(self.A_filenames)


def get_transform(convert=True, normalize=False, is_pre=True, isRGB=True):

    transform_list = [] 
    if convert:
        transform_list += [transforms.ToTensor()]
    if normalize:
        if is_pre:
            if isRGB:
                transform_list += [transforms.Normalize((0.4355, 0.4382, 0.4335),
                                                        (0.2096, 0.2089, 0.2095))]    # LEVIR-CD/train/A
                # transform_list += [transforms.Normalize((0.4310, 0.4498, 0.4480),
                #                                         (0.2085, 0.2069, 0.2054))]    # SYSUtry/train/A
                # transform_list += [transforms.Normalize((0.5, 0.5, 0.5),
                #                                        (0.5, 0.5, 0.5))]                # WHU256/train/B                                
            else:  
                transform_list += [transforms.Normalize((0.1655, 0.1708, 0.1481, 0.1067),
                                                        (0.0371, 0.0466, 0.0590, 0.0713))] # GF-2/jinzhou/A
                                                        
        else:
            if isRGB:
                transform_list += [transforms.Normalize((0.3306, 0.3351, 0.3297), 
                                                        (0.1612, 0.1667, 0.1607))]     # LEVIR-CD/train/B
                # transform_list += [transforms.Normalize((0.4310, 0.4364, 0.4275), 
                #                                         (0.1966, 0.1983, 0.1934))]     # SYSUTry/train/B
                # transform_list += [transforms.Normalize((0.5, 0.5, 0.5),
                #                                         (0.5, 0.5, 0.5))]                # WHU256/train/B
            else:  
                transform_list += [transforms.Normalize((0.2090, 0.1837, 0.1604, 0.1323), 
                                                        (0.0452, 0.0571, 0.0974, 0.1383))] # GF-2/jinzhou/B

  
                                
    return transforms.Compose(transform_list)



