import torch
import torch.nn as nn
import matplotlib.pyplot as plt  
import torch.nn.functional as F
from options import parser

from Encoder import encoder
from Decoder import decoder
from basic_module import *
from SR import Semantic_refine

opt = parser.parse_args()

class CDNet(nn.Module):
    def __init__(self, node_num):  #, backbone, ss
        super(CDNet,self).__init__()

        self.node_num_4 = node_num[0]
        self.node_num_5 = node_num[1]
        self.encoder_RSI_1 = encoder()
        self.encoder_RSI_2 = encoder()
        
       
        self.semantic_refine_4 = Semantic_refine(in_ch=64, node_num=self.node_num_4*self.node_num_4)
        self.semantic_refine_5 = Semantic_refine(in_ch=64, node_num=self.node_num_5*self.node_num_5)


        self.decoder = decoder()
        self.conv = nn.Sequential(Conv3ReLU(64, 32),
                    nn.Conv2d(32, opt.out_cls, kernel_size=1, bias=True),
                    nn.Sigmoid())
        
    
    def forward(self, input1, input2):
        
        ###--------------------------------------------------------------###
        ###                           Encoder                            ###
        ###--------------------------------------------------------------###

        image_1_list = self.encoder_RSI_1(input1)
        image_2_list = self.encoder_RSI_2(input2)

    
        ### ------------------ Semantic Refinement --------------------- ###
    
        token_4_list  = self.semantic_refine_4(image_1_list[3], image_2_list[3])
        token_5_list  = self.semantic_refine_5(image_1_list[4], image_2_list[4])

        ###--------------------------------------------------------------###
        ###                           Decoder                            ###
        ###--------------------------------------------------------------###
        feat_out, Refine3_ds, Refine2_ds, Refine1_ds  = self.decoder(image_1_list, image_2_list, token_4_list, token_5_list) 

        ###--------------------------------------------------------------###
        ###                           Output                             ###
        ###--------------------------------------------------------------###

        output = self.conv(feat_out)     # [B, 1, 128, 128]
        output = F.interpolate(output, scale_factor=2, mode='bilinear', align_corners=False)  # [B, 1, 256, 256]

        return output, Refine3_ds, Refine2_ds, Refine1_ds 

