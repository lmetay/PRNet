
"""
    Progressive Refinement Decoder
"""

import torch
import torch.nn as nn
import numpy as np  
import torch.nn.functional as F
from basic_module import *



class decoder(nn.Module):
    def __init__(self): 
        super(decoder, self).__init__()
        channels = [64, 64, 64, 64, 64]

        self.Self_R1 = Self_R(channels[2])
        self.Self_R2 = Self_R(channels[1])
        self.Self_R3 = Self_R(channels[0])

        self.diff_1 = Diff_Enhance(channels[4], channels[3], is_previous=False)
        self.diff_2 = Diff_Enhance(channels[3], channels[2], is_previous=True)
        self.diff_3 = Diff_Enhance(channels[2], channels[1], is_previous=True)
        self.diff_4 = Diff_Enhance(channels[1], channels[0], is_previous=True)
        self.diff_5 = Diff_Enhance(channels[0], channels[0], is_previous=True)

        self.conv = nn.Conv2d(channels[0], channels[0], kernel_size=3, padding=1)
        
        self._init_weight()
 
    def forward(self, image_1_list, image_2_list, token_4_list, token_5_list):  
        zero_block = torch.ones_like(image_1_list[4])               
        de_feat5 = self.diff_1(token_5_list[0], token_5_list[1], zero_block)                                        

        de_feat4 = self.diff_2(token_4_list[0], token_4_list[1], de_feat5)  
        de_feat4_up = US2(de_feat4)

        de_feat3 = self.diff_3(image_1_list[2], image_2_list[2], de_feat4_up)  
        Refine3, super_R3 = self.Self_R1(de_feat3)    
        de_feat3_up = US2(Refine3)
        
        de_feat2 = self.diff_4(image_1_list[1], image_2_list[1], de_feat3_up)  
        Refine2, super_R2 = self.Self_R2(de_feat2) 
        de_feat2_up = US2(Refine2)

        de_feat1 = self.diff_5(image_1_list[0], image_2_list[0], de_feat2_up)  
        Refine1, super_R1 = self.Self_R3(de_feat1) 
    
        
        ### -----------------  supervision -------------------###
        Refine3_ds = US8(super_R3)                            
        Refine2_ds = US4(super_R2)                          
        Refine1_ds = US2(super_R1)  

        return Refine1, Refine3_ds, Refine2_ds, Refine1_ds


    def _init_weight(self):        
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0) 
    

class Diff_Enhance(nn.Module):
    def __init__(self, in_channels, out_channels, is_previous=True):
        super(Diff_Enhance,self).__init__()
        self.is_previous = is_previous
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.conv1 = nn.Sequential(
                         nn.Conv2d(in_channels=self.in_channels, out_channels=self.in_channels, kernel_size=3, padding=1, bias=False),
                         nn.ReLU(inplace=True),
        )
        self.conv2 = nn.Sequential(
                         nn.Conv2d(in_channels=self.in_channels, out_channels=self.in_channels, kernel_size=3, padding=1, bias=False),
                         nn.ReLU(inplace=True),
        )
        self.conv3 = Conv3ReLU(self.in_channels, self.out_channels)

    def forward(self, feat1, feat2, pre_feat):
        input = abs(feat1-feat2)
        output1 = self.conv1(input)                                         
        output2 = self.conv2(output1)                                         
        
        if self.is_previous:
            feat = input + output1 + output2 + pre_feat
        else:
            feat = input + output1 + output2                                    

        output = self.conv3(feat)                                       

        return output

