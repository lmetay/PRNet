
from copy import copy
import torch
import torch.nn as nn
import matplotlib.pyplot as plt  
import torch.nn.functional as F



class Semantic_refine(nn.Module):
    def __init__(self, in_ch, node_num): 
        super(Semantic_refine,self).__init__()
        self.in_ch = in_ch
        self.node_num = node_num
        self.num_s = int(2 * self.node_num)
        self.num_n = int(1 * self.node_num)
        self._get_graph_tokens = _get_graph_tokens(self.in_ch, self.node_num)
    
        self.enc_graph_embedding = nn.Parameter(torch.randn(1, self.node_num*4, self.node_num))  
        
        self.token_encode = TransformerEncoder(
                            dim=self.node_num,    # input feature's channel
                            depth=1, 
                            n_heads=8,
                            head_dim=64,
                            mlp_dim=2*self.node_num,
                            dropout_rate=0.)
        self.conv_extend_1 = nn.Conv2d(self.num_s, self.in_ch, kernel_size=1, bias=False)
        self.blocker_1 = nn.BatchNorm2d(self.in_ch, eps=1e-04)
        self.conv_extend_2 = nn.Conv2d(self.num_s, self.in_ch, kernel_size=1, bias=False)
        self.blocker_2 = nn.BatchNorm2d(self.in_ch, eps=1e-04)

    
    def forward(self, input1, input2):

        input1_graph_state, input1_rproj_reshaped = self._get_graph_tokens(input1)     
        input2_graph_state, input2_rproj_reshaped = self._get_graph_tokens(input2)     

        graph_token = torch.cat([input1_graph_state, input2_graph_state], dim=1)    
        graph_token += self.enc_graph_embedding                                     
        graph_token = self.token_encode(graph_token)
        graph_token1, graph_token2 = torch.chunk(graph_token, 2, dim=1) 
        
        b,c,h,w = input1.size()
        input1_state_reshaped = torch.matmul(graph_token1, input1_rproj_reshaped)     
        input1_state = input1_state_reshaped.view(b, self.num_s, *input1.size()[2:])  
        output1 = input1 + self.blocker_1(self.conv_extend_1(input1_state))             

        input2_state_reshaped = torch.matmul(graph_token2, input2_rproj_reshaped)    
        input2_state = input2_state_reshaped.view(b, self.num_s, *input2.size()[2:]) 
        output2 = input2 + self.blocker_2(self.conv_extend_2(input2_state))  

        return output1, output2   



class _get_graph_tokens(nn.Module):
    def __init__(self, num_in, num_mid):  
        super(_get_graph_tokens,self).__init__()

        self.num_s = int(2 * num_mid)
        self.num_n = int(1 * num_mid)
        self.conv_state = nn.Conv2d(num_in, self.num_s, kernel_size=1)
        self.conv_proj = nn.Conv2d(num_in, self.num_n, kernel_size=1)

    def forward(self, x):
        B = x.size(0)    
        x_state_reshaped = self.conv_state(x).view(B, self.num_s, -1) 
        x_proj_reshaped = self.conv_proj(x).view(B, self.num_n, -1)   
        x_rproj_reshaped = x_proj_reshaped                            
        graph_state = torch.matmul(x_state_reshaped, x_proj_reshaped.permute(0, 2, 1))  
        
        return graph_state, x_rproj_reshaped


class TransformerEncoder(nn.Module):
    def __init__(self, dim, depth, n_heads, head_dim, mlp_dim, dropout_rate):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Residual(PreNorm(dim, SelfAttention(dim, n_heads, head_dim, dropout_rate))),  
                Residual(PreNorm(dim, FeedForward(dim, mlp_dim, dropout_rate)))
            ]))

    def forward(self, x):   
        for att, ff in self.layers:
            x = att(x)
            x = ff(x)
        return x     


class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(x, **kwargs) + x

   
class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)  
        self.fn = fn

    def forward(self, x, **kwargs):   
        return self.fn(self.norm(x), **kwargs)  

class CrossAttention(nn.Module):
    def __init__(self, dim, n_heads=8, head_dim=64, dropout_rate=0., apply_softmax=True):
        super().__init__() 

        inner_dim = head_dim * n_heads
        self.n_heads = n_heads
        self.scale = dim ** -0.5

        self.apply_softmax = apply_softmax
        
        self.fc_q = nn.Linear(dim, inner_dim, bias=False)   
        self.fc_v = nn.Linear(dim, inner_dim, bias=False)

        self.fc_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout_rate)
        )

    def forward(self, x, ref): 
        b, n = x.shape[:2]   
        h = self.n_heads    

        q = self.fc_q(x)    
        k = self.fc_k(ref)  
        v = self.fc_v(ref)  

        q = q.reshape((b,n,h,-1)).permute((0,2,1,3))               
        k = k.reshape((b,ref.shape[1],h,-1)).permute((0,2,1,3))     
        v = v.reshape((b,ref.shape[1],h,-1)).permute((0,2,1,3))    

        mult = torch.matmul(q, k.transpose(-1,-2)) * self.scale     

        if self.apply_softmax:
            mult = F.softmax(mult, dim=-1)     

        out = torch.matmul(mult, v)           
        out = out.permute((0,2,1,3)).flatten(2) 
        return self.fc_out(out)


class SelfAttention(CrossAttention):
    def forward(self, x):
        return super().forward(x, x)


class FeedForward(nn.Sequential):     
    def __init__(self, dim, hidden_dim, dropout_rate=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout_rate)
        )
    def forward(self, x):
        return self.net(x)  


