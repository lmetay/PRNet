
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional
import numpy as np


class dice_loss_binary_class(nn.Module):
    def __init__(self, batch=True):
        super(dice_loss_binary_class, self).__init__()
        self.batch = batch
        
    def soft_dice_coeff(self, y_true, y_pred):
        smooth = 0.00001
        if self.batch:
            i = torch.sum(y_true)
            j = torch.sum(y_pred)
            intersection = torch.sum(y_true * y_pred) 
        else:
            i = y_true.sum(1).sum(1).sum(1)
            j = y_pred.sum(1).sum(1).sum(1)
            intersection = (y_true * y_pred).sum(1).sum(1).sum(1)
        score = (2. * intersection + smooth) / (i + j + smooth)
        return score.mean()

    def soft_dice_loss(self, y_true, y_pred):
        loss = 1 - self.soft_dice_coeff(y_true, y_pred)
        return loss
        
    def __call__(self, y_true, y_pred):
        return self.soft_dice_loss(y_true, y_pred.to(dtype=torch.float32))



class dice_bce_loss_binary_class(nn.Module):
    """    Binary    """
    def __init__(self):
        super(dice_bce_loss_binary_class, self).__init__()
        self.bce_loss = nn.BCELoss()
        self.binary_loss = dice_loss_binary_class()
    
    def __call__(self, scores, labels, do_sigmoid=True):
        if len(scores.shape)>3:
            scores = scores.squeeze(1)
        if len(labels.shape)>3:
            labels = labels.squeeze(1)
        if do_sigmoid:
            scores = torch.sigmoid(scores.clone())
        diceloss = self.binary_loss(scores, labels)
        bceloss = self.bce_loss(scores, labels)
        return diceloss+bceloss 




class CD_loss(nn.Module):
    def __init__(self):
        super(CD_loss, self).__init__()
    
    def forward(self, pre_cd, Refine3_ds, Refine2_ds, Refine1_ds, label):


        criterion = dice_bce_loss_binary_class() 
        loss_cd = torch.tensor(0.0).cuda()
        loss_cd = criterion(pre_cd, label, False)  
        loss1 = criterion(Refine3_ds, label, False) 
        loss2 = criterion(Refine2_ds, label, False) 
        loss3 = criterion(Refine1_ds, label, False) 

        loss = loss_cd + loss1 + loss2 + loss3
        return loss


class CD_loss_val(nn.Module):
    def __init__(self):
        super(CD_loss_val, self).__init__()
    
    def forward(self, pre_cd, label):

        criterion = dice_bce_loss_binary_class() 
        loss_cd = torch.tensor(0.0).cuda()
        loss_cd = criterion(pre_cd, label, False)  

        return loss_cd