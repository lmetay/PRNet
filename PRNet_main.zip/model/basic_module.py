import torch
import torch.nn as nn
import torch.nn.functional as F
import math


def conv3x3(in_planes, out_planes, stride=1, groups=1, dilation=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=dilation, groups=groups, bias=False, dilation=dilation)

def _init_weight(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()


class downsample(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(downsample, self).__init__()
        self.downsample = nn.Sequential(
                                    nn.Conv2d(in_channels, out_channels,kernel_size=1, stride=2, bias=False),
                                    nn.BatchNorm2d(out_channels)
                            ) 
    def forward(self, x):
        return self.downsample(x)

class Conv3BN(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Conv3BN, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
    def forward(self, x):
        return self.bn(self.conv(x))
    def initialize(self):
        _init_weight(self)


class Conv1ReLU(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Conv1ReLU, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, padding=0, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))
    def initialize(self):
        _init_weight(self)


class Conv3ReLU(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Conv3ReLU, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))
    def initialize(self):
        _init_weight(self)

class Conv5ReLU(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Conv5ReLU, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=5, stride=1, padding=2, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))
    def initialize(self):
        _init_weight(self)


class Conv7ReLU(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Conv7ReLU, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=7, stride=1, padding=3, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))
    def initialize(self):
        _init_weight(self)



""" Self Refinement Module """
class Self_R(nn.Module):
    def __init__(self, in_channel):
        super(Self_R, self).__init__()

        self.conv1 = Conv3ReLU(in_channel, int(in_channel//2))
        self.conv2 = nn.Conv2d(int(in_channel//2), int(in_channel//2), kernel_size=1, stride=1, padding=0, bias=False)
        self.conv3 = nn.Sequential(conv3x3(int(in_channel//2), 1), nn.Sigmoid() )
   

    def forward(self, diff_feat):

        res = diff_feat                       
        out1 = self.conv1(diff_feat)                    
        out2 = self.conv2(out1)               
        out3 = self.conv3(out2)                             
        out =  out3*diff_feat + res          
        return out, out3           

    def initialize(self):
        _init_weight(self)



class Edge_ext(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Edge_ext, self).__init__()
        self.Conv3ReLU = Conv3ReLU(in_channels, in_channels)
        self.Conv5ReLU = Conv5ReLU(in_channels, in_channels)
        self.Conv7ReLU = Conv7ReLU(in_channels, in_channels)
        self.conv = nn.Conv2d(in_channels*3, out_channels, kernel_size=1, padding=0, bias=False)
    
    def forward(self, x):
        S_edge_feat, M_edge_feat, B_edge_feat = self.Conv3ReLU(x), self.Conv5ReLU(x), self.Conv7ReLU(x)
        edge_feat = nn.BatchNorm2d(self.conv(torch.cat((S_edge_feat, M_edge_feat, B_edge_feat), dim=1)))

        return edge_feat
    
    def initialize(self):
        _init_weight(self)

def US2(x):
    return F.interpolate(x, scale_factor=2, mode='bilinear', align_corners=False)


def US4(x):
    return F.interpolate(x, scale_factor=4, mode='bilinear', align_corners=False)


def US8(x):
    return F.interpolate(x, scale_factor=8, mode='bilinear', align_corners=False)


