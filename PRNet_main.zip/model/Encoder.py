import torch
import torch.nn as nn
import math
from basic_module import downsample,Edge_ext, Conv1ReLU, conv3x3


class encoder(nn.Module):
    def __init__(self):
        super(encoder, self).__init__()

        self.backbone = ResNet(BasicBlock, [2, 2, 2, 2], BatchNorm=nn.BatchNorm2d)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.Edge1 = Edge_ext(64, 64)
        self.edge_map_1 = Conv1ReLU(64, 64)
        self.downsample_1 = downsample(64, 64)
        self.Edge2 = Edge_ext(64, 64)
        self.downsample_2 = downsample(64, 64)

        self.conv1 = nn.Conv2d(64+64, 64, kernel_size=1, stride=1, padding=0, bias=False)
        self.conv2 = nn.Conv2d(64+64, 64, kernel_size=1, stride=1, padding=0, bias=False)

    def forward(self, input):
        fea_stage1 = self.backbone.C1(input)                                     
        edge_stage1 = self.Edge1(fea_stage1)                            
        EG_1_1 = self.downsample_1(edge_stage1)                        
        fea_stage2 = self.backbone.C2(self.maxpool(fea_stage1))            
        Out_stage2 = self.conv1(torch.cat((EG_1_1, fea_stage2), dim=1))           

        edge_stage2 = self.Edge2(Out_stage2)                                    
        EG_1_2 = self.downsample_2(edge_stage2)                                  
        fea_stage3 = self.backbone.C3(Out_stage2)                                
        Out_stage3 = self.conv2(torch.cat((EG_1_2, fea_stage3), dim=1))            

        Out_stage4 = self.backbone.C4(Out_stage3)                                  
        Out_stage5 = self.backbone.C5(Out_stage4)

        return fea_stage1, Out_stage2, Out_stage3, Out_stage4, Out_stage5
        

 
    def build_backbone(self, bb_type):
        if bb_type == 'ResNet18':
            BatchNorm = nn.BatchNorm2d
            model = ResNet(BasicBlock, [2, 2, 2, 2], BatchNorm, in_c=3)
            model._load_pretrained_model()
        return bb_type





class ResNet(nn.Module):

    def __init__(self, block, layers, BatchNorm, pretrained=True, in_c=3):
        self.inplanes = 64
        self.in_c = in_c
        # print('in_c: ',self.in_c)
        super(ResNet, self).__init__()
        blocks = [1, 2, 4]
        strides = [1, 2, 2, 1]      
        dilations = [1, 1, 1, 2]    

        self.C1 = nn.Sequential(
                    nn.Conv2d(self.in_c, 64, kernel_size=7, stride=2, padding=3, bias=False),
                    nn.BatchNorm2d(64),
                    nn.ReLU(inplace=True))
        self.C2 = self._make_layer(block, 64, layers[0], stride=strides[0], dilation=dilations[0], BatchNorm=BatchNorm)
        self.C3 = self._make_layer(block, 64, layers[1], stride=strides[1], dilation=dilations[1], BatchNorm=BatchNorm)
        self.C4 = self._make_layer(block, 64, layers[2], stride=strides[2], dilation=dilations[2], BatchNorm=BatchNorm)
        self.C5 = self._make_layer(block, 64, layers[3], stride=strides[3], dilation=dilations[3], BatchNorm=BatchNorm)

    def _make_layer(self, block, planes, blocks, stride=1, dilation=1, BatchNorm=None):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                BatchNorm(planes * block.expansion),
            ) 

        layers = []
        layers.append(block(self.inplanes, planes, stride, dilation, downsample, BatchNorm))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes, dilation=dilation, BatchNorm=BatchNorm))

        return nn.Sequential(*layers)

    def _make_MG_unit(self, block, planes, blocks, stride=1, dilation=1, BatchNorm=None):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                BatchNorm(planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, dilation=blocks[0]*dilation,
                            downsample=downsample, BatchNorm=BatchNorm))
        self.inplanes = planes * block.expansion
        for i in range(1, len(blocks)):
            layers.append(block(self.inplanes, planes, stride=1,
                                dilation=blocks[i]*dilation, BatchNorm=BatchNorm))

        return nn.Sequential(*layers)

    def forward(self):
        return self.C1, self.C2, self.C3, self.C4, self.C5

    def _init_weight(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()



class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, dilation=1, downsample=None, BatchNorm=None):
        super(BasicBlock, self).__init__()

        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=3, stride=stride,
                               dilation=dilation, padding=dilation, bias=False)
        self.bn1 = BatchNorm(planes)

        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(planes, planes)
        self.bn2 = BatchNorm(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)

        return out



